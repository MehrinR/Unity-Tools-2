using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class LanguageEditorWindow : EditorWindow
{
    private List<LanguageSO> allLanguages;
    private LanguageSO selectedLanguage;
    private string newKey = string.Empty; 
    private string newValue = string.Empty;
    private Vector2 scrollPosition;

    [MenuItem("Tools/Language Editor")]
    public static void ShowWindow()
    {
        GetWindow<LanguageEditorWindow>("Language Editor");
    }

    private void OnEnable()
    {
        // Find all LanguageSO assets in the project
        allLanguages = AssetDatabase.FindAssets("t:LanguageSO")
            .Select(guid => AssetDatabase.LoadAssetAtPath<LanguageSO>(AssetDatabase.GUIDToAssetPath(guid)))
            .ToList();
    }

    private void OnGUI()
    {
        GUILayout.Label("Language Localization Manager", EditorStyles.boldLabel);

        // Dropdown to select a language file
        string[] languageOptions = allLanguages.Select(lang => lang.name).ToArray();
        int selectedIndex = selectedLanguage != null ? allLanguages.IndexOf(selectedLanguage) : -1;
        selectedIndex = EditorGUILayout.Popup("Select Language", selectedIndex, languageOptions);

        if (selectedIndex >= 0)
        {
            selectedLanguage = allLanguages[selectedIndex];
        }

        if (selectedLanguage != null)
        {
            EditorGUILayout.Space();
            DrawKeyValuePairs();
            EditorGUILayout.Space();
            DrawAddKeyValuePair();
        }
        else
        {
            EditorGUILayout.HelpBox("Select a Language file to edit.", MessageType.Info);
        }
    }

    private void DrawKeyValuePairs()
    {
        GUILayout.Label("Key-Value Pairs", EditorStyles.boldLabel);
        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);

        for (int i = 0; i < selectedLanguage.keys.Count; i++)
        {
            EditorGUILayout.BeginHorizontal();

            selectedLanguage.keys[i] = EditorGUILayout.TextField("Key", selectedLanguage.keys[i]);
            selectedLanguage.values[i] = EditorGUILayout.TextField("Value", selectedLanguage.values[i]);

            if (GUILayout.Button("Delete", GUILayout.Width(70)))
            {
                RemoveKey(selectedLanguage.keys[i]);
            }

            EditorGUILayout.EndHorizontal();
        }

        EditorGUILayout.EndScrollView();

        EditorUtility.SetDirty(selectedLanguage);
    }

    private void DrawAddKeyValuePair()
    {
        GUILayout.Label("Add New Key-Value Pair", EditorStyles.boldLabel);

        newKey = EditorGUILayout.TextField("New Key", newKey);
        newValue = EditorGUILayout.TextField("New Value", newValue);

        if (GUILayout.Button("Add Key-Value Pair"))
        {
            if (!selectedLanguage.keys.Contains(newKey))
            {
                AddKeyToAllLanguages(newKey, newValue);

                newKey = string.Empty;
                newValue = string.Empty;

                EditorUtility.SetDirty(selectedLanguage);
            }
            else
            {
                EditorUtility.DisplayDialog("Error", "Key already exists!", "OK");
            }
        }
    }

    private void AddKeyToAllLanguages(string key, string value)
    {
        foreach (var language in allLanguages)
        {
            if (!language.keys.Contains(key))
            {
                language.keys.Add(key);
                language.values.Add(language == selectedLanguage ? value : ""); // Default to empty for other languages
            }
        }
    }

    private void RemoveKey(string key)
    {
        foreach (var language in allLanguages)
        {
            int index = language.keys.IndexOf(key);
            if (index >= 0)
            {
                language.keys.RemoveAt(index);
                language.values.RemoveAt(index);
            }
        }
    }
}
