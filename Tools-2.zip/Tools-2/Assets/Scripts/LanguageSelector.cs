using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class LanguageSelector : MonoBehaviour
{
    public TMP_Dropdown languageDropdown;

    private void Start()
    {
        InitializeDropdown();
    }

    private void InitializeDropdown()
    {
        languageDropdown.ClearOptions();

        List<string> languageOptions = new List<string>();
        foreach (var language in LanguageController.Instance.languages)
        {
            languageOptions.Add(language.name);
        }

        languageDropdown.AddOptions(languageOptions);

        // Attach listener to handle language change
        languageDropdown.onValueChanged.AddListener(delegate { OnLanguageChanged(languageDropdown.value); });

        // Set initial selection to the first language
        languageDropdown.value = 0;
        OnLanguageChanged(0);
    }

    private void OnLanguageChanged(int languageIndex)
    {
        LanguageController.Instance.SetLanguage(languageIndex);
    }
}
