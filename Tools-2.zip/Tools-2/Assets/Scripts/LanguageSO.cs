using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObjects/Language", order = 1)]
public class LanguageSO : ScriptableObject
{
    public List<string> keys;  // keys as List<string>
    public List<string> values;

    public Dictionary<string, string> languageDictionary = new Dictionary<string, string>();

    private void OnEnable()
    {
        languageDictionary.Clear();
        for (int i = 0; i < keys.Count; i++)
        {
            if (i < values.Count)
            {
                languageDictionary[keys[i]] = values[i];
            }
        }
    }
}
