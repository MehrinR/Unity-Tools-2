using UnityEngine;
using System.Collections.Generic;
using System;

public class LanguageController : MonoBehaviour
{
    public static LanguageController Instance { get; private set; }

    public List<LanguageSO> languages;
    private LanguageSO currentLanguage;

    public event Action OnLanguageChanged;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SetLanguage(int index)
    {
        if (index < 0 || index >= languages.Count) return;

        currentLanguage = languages[index];
        OnLanguageChanged?.Invoke();
    }

    public string GetText(string key)
    {
        return currentLanguage != null && currentLanguage.languageDictionary.ContainsKey(key)
            ? currentLanguage.languageDictionary[key]
            : $"Missing Key: {key}";
    }
}
