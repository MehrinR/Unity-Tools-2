using UnityEngine;
using TMPro;

public class DisplayText : MonoBehaviour
{
    public string displayKey;
    private TMP_Text displayText;

    private void Awake()
    {
        displayText = GetComponent<TMP_Text>();
    }

    private void OnEnable()
    {
        LanguageController.Instance.OnLanguageChanged += UpdateText;
        UpdateText(); // Initial update
    }

    private void OnDisable()
    {
        LanguageController.Instance.OnLanguageChanged -= UpdateText;
    }

    private void UpdateText()
    {
        displayText.text = LanguageController.Instance.GetText(displayKey);
    }
}
